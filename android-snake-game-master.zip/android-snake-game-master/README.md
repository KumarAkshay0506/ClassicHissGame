# Android Snake Game

A simple android snake game based on android canvas
