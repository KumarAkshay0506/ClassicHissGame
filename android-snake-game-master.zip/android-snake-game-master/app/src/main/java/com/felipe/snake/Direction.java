package com.felipe.snake;

public enum Direction {
	LEFT, RIGHT, UP, DOWN;
}
